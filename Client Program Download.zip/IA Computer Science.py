# ------- These are the main libraries used in the program ------ #
from tkinter import *
from tkinter.font import BOLD
import tkinter.ttk as ttk
import tkinter.messagebox as tkMessageBox
from cProfile import label
import time
import sqlite3
 
# ------- Creation of the login part of the program ------- #
programa_cliente = Tk()
programa_cliente.title("Iniciar Sesion")
programa_cliente.geometry("600x330")
programa_cliente.configure(bg="#698fc2")
programa_cliente.iconbitmap("icon.ico")

# ------- Validation point of entries to see if information is correct or incorrect ------- #
def verficacion():
    MessageBoxLoginCorrecto = "Verificado!"
    MessageBoxIncorrecto = "Datos incorrectos!"
    cajadeususario = entrydelusuario.get()
    Contraseña = entrydelacontraseña.get()
    if cajadeususario == "Ivan" and "Dani" and Contraseña ==  "123":
        tkMessageBox.showinfo(MessageBoxLoginCorrecto, "¡Has iniciado sesion correctamente! " + cajadeususario)
        programa_cliente.destroy()
        programa_principal_cliente()
    else:
        tkMessageBox.showinfo(MessageBoxIncorrecto, "¡Datos puestos incorrectos!")
# ------ Getting information from the labels
entrydelusuario = Entry(programa_cliente, borderwidth=2, width = 25)
entrydelusuario.place(x=320, y=125)
entrydelacontraseña = Entry(programa_cliente, show = '*', borderwidth=2, width = 25)
entrydelacontraseña.place(x=320, y=170)
 
# ------- Labels of the sections for the login ------- #
titulo_programa = Label(programa_cliente, text="1 Parking Login",font=("Arial",35, BOLD),fg="white",bg="#698fc2")
titulo_programa.place(x=140, y=40)
cajadeususario = Label(programa_cliente, text="Usuario : ",font=("Arial",15, BOLD),fg="white",bg="#698fc2")
cajadeususario.place(x=210, y=120)
cajadecontraseña = Label(programa_cliente, text=" Contraseña : ",font=("Arial",15, BOLD),fg="white",bg="#698fc2")
cajadecontraseña.place(x=170, y=168)
boton_login = PhotoImage(file="loginbtn.png")
imagen_boton = Label(image=boton_login)
button = Button(programa_cliente, image=boton_login, command=verficacion, borderwidth=0, fg="#698fc2")
button.place(x=270, y=240)

#Button(text="login",font=("Arial", 13, BOLD),command=verficacion,bg="green",fg="white").place(x=270, y=240)

# ------- Creation of the database of the second program ------- #
def base_de_datos():
    global base_conexion, conexion_db
   
    base_conexion = sqlite3.connect("base_datos.db")
    conexion_db = base_conexion.cursor()
   
    conexion_db.execute("CREATE TABLE IF NOT EXISTS TRABAJADORES (ID INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, apellido TEXT, correoelectronico TEXT, numerotelefono TEXT, salario TEXT)")
 
# ------- Main program where database is displayed ------- #
def programa_principal_cliente():
    def vision_completa_programa():
        # ------- Creation of the tkinter program ------- #
        programa_base_datos = Tk()
        programa_base_datos.geometry("1310x690")
        programa_base_datos.configure(bg="#698fc2")
        programa_base_datos.title("Base de datos 1 Parking Trabajadores")
        programa_base_datos.iconbitmap("icon.ico")
        # ------- Clock to represent the time to the client ------- #
        def reloj_programa():
            label = Label(programa_base_datos, font=("Times New Roman", 20, 'bold'), bg="#698fc2", fg="white", bd = 5)
            label.place(x=490, y=10)
            text_input = time.strftime("%d/%m/%Y | %H:%M:%S") #date/month/year | hour/minute/seconds
            label.config(text=text_input)
            label.after(200, reloj_programa)
        reloj_programa()
        
        # ------- Top Menu for the client to interact with ------- #
        barmenu = Menu(programa_base_datos)
        programa_base_datos.config(menu=barmenu)
        # ------- Greeting message pop up ------- #
        def sub_menu1():
            tkMessageBox.showinfo('Mensaje del desarrollador','Bienvenido a su base de datos de trabajadores, siéntese libre de ingresar cualquier informacion.')
        menu1 = Menu(barmenu, tearoff=0)
        barmenu.add_cascade(label="Ayuda", menu=menu1)
        menu1.add_cascade(label="Informacion", command = sub_menu1)
        # ------- Contact message pop up ------- #
        def sub_menu2():
            tkMessageBox.showinfo('Contactar Desarollador','Para contactarme mandeme un email a alvaro@arguelles.cc le respondere en cuando pueda. Gracias y espero que le guste el programa')
        menu2 = Menu(barmenu, tearoff=0)
        barmenu.add_cascade(label="Contactar", menu=menu2)
        menu2.add_cascade(label="Contactar Desarollador", command = sub_menu2)
        
        # ------- Database code for the interaction between the client and program ------- #
        global tree
        global SEARCH
        global nombre,apellido,correoelectronico,numerotelefono,salario
        SEARCH = StringVar()
        # ------ Fields and columns of the database ------ #
        nombre = StringVar()
        apellido = StringVar()
        correoelectronico = StringVar()
        numerotelefono = IntVar()
        salario= StringVar()
        
        # ------- Settings for the input section on the left  -------
        formulario_ajustes = Frame(programa_base_datos, height=525, width=300, bg="#547db3")
        formulario_ajustes.place(x=50,y=130)
 
        # ------- Settings for the databse displayement on the right ------- #
        ajuste_base_datos_grafico = Frame(programa_base_datos, width=600)
        ajuste_base_datos_grafico.place(x=400,y=130)

        titulo_programa = Label(text="Base de datos de Trabajadores", font=('Arial', 20, 'bold'), fg = "white",  bg="#698fc2")
        titulo_programa.place(x=440, y=50)
       
        # ------- This is the left side where client inputs the data to be stored in the database ------ #
        Label(text="Formulario de Informacion", font=("Arial", 14, BOLD, UNDERLINE),bg="#547db3",fg="white").place(x=77, y=140)
        Label(text="Nombre", font=("Arial", 16, BOLD),bg="#547db3",fg="white").place(x=77, y=180)
        Entry(font=("Arial",13),textvariable=nombre, width=17).place(x=77, y=220)
        Label(text="Apellido", font=("Arial", 16, BOLD),bg="#547db3",fg="white").place(x=77, y=260)
        Entry(font=("Arial", 13),textvariable=apellido, width=17).place(x=77, y=300)
        Label(text="Correo", font=("Arial", 16, BOLD),bg="#547db3",fg="white").place(x=77, y=340)
        Entry(font=("Arial", 13),textvariable=correoelectronico, width=17).place(x=77, y=380)
        Label(text="Numero de telefono", font=("Arial", 16, BOLD),bg="#547db3",fg="white").place(x=77, y=420)
        Entry(font=("Arial", 13),textvariable=numerotelefono).place(x=77, y=460)
        Label(text="Salario", font=("Arial", 16, BOLD),bg="#547db3",fg="white").place(x=77, y=500)
        Entry(font=("Arial", 13),textvariable=salario).place(x=77, y=540) 
        
        Button(text="Cerrar sesión",font=("Arial", 13, BOLD),command=programa_base_datos.destroy,bg="#ff3333",fg="white").place(x=1140,y=50)
        Button(formulario_ajustes,text="Guardar",font=("Arial", 13, BOLD),command=guardar_informacion,bg="#36a312",fg="white").place(x=25,y=450)
        Button(formulario_ajustes, text="Actualizar", command=actualizar,bg="orange", font=("Arial", 13, BOLD), fg="white").place(x=112, y=450)
        Button(formulario_ajustes, text="Eliminar", command=eliminar_informacion,bg="red", font=("Arial", 13, BOLD), fg="white").place(x=210,y=450)

 
        # ------- Scrollbar incase the client needs to work around the database ------ #
        barra_horizontal = Scrollbar(ajuste_base_datos_grafico, orient=HORIZONTAL)
        barra_vertical = Scrollbar(ajuste_base_datos_grafico, orient=VERTICAL)
        tree = ttk.Treeview(ajuste_base_datos_grafico,columns=("ID", "nombre", "apellido", "correoelectronico", "numerotelefono", "salario"), selectmode="extended", height=24, yscrollcommand=barra_vertical.set, xscrollcommand=barra_horizontal.set)
        barra_vertical.config(command=tree.yview)
        barra_vertical.pack(side=RIGHT, fill=Y)
        barra_horizontal.config(command=tree.xview)
        barra_horizontal.pack(side=BOTTOM, fill=X)
        tree.heading('ID', text="ID", anchor=W)
        tree.heading('nombre', text="Nombre", anchor=W)
        tree.heading('apellido', text="Apellido", anchor=W)
        tree.heading('correoelectronico', text="Correo", anchor=W)
        tree.heading('numerotelefono', text="Telefono", anchor=W)
        tree.heading('salario', text="Salario", anchor=W)

        tree.column('#0', stretch=NO, width=0)
        tree.column('#1', stretch=NO, width=90)
        tree.column('#2', stretch=NO, width=110)
        tree.column('#3', stretch=NO, width=130)
        tree.column('#4', stretch=NO, width=150)
        tree.column('#5', stretch=NO, width=160)
        tree.pack()
        vision_base_datos()
        
    def guardar_informacion():
        base_de_datos()
        nombre_worker=nombre.get()
        apellido_worker=apellido.get()
        correoelectronico_contact=correoelectronico.get()
        numerotelefono_worker=numerotelefono.get()
        salario_trabajador=salario.get()
        if nombre_worker=='' or apellido_worker==''or correoelectronico_contact=='' or numerotelefono_worker=='' or salario_trabajador=='':
            tkMessageBox.showinfo("Warning","¡Rellene los campos de informacion correctos!")
        else:
          if "@" and "." in correoelectronico_contact:
            pass
          else:
            return tkMessageBox.showinfo("Warning", "¡No ha hecho el formato de correo correcto! ")
          base_conexion.execute('INSERT INTO TRABAJADORES (nombre,apellido,correoelectronico,numerotelefono,salario) \
                  VALUES (?,?,?,?,?)',(nombre_worker,apellido_worker,correoelectronico_contact,numerotelefono_worker,salario_trabajador));
          base_conexion.commit()
          tkMessageBox.showinfo("Message","¡Informacion guardada correctamente en la base de datos!")
          vision_base_datos()
          base_conexion.close()
    
    def actualizar():
        base_de_datos()
        nombre_worker=nombre.get()
        apellido_worker=apellido.get()
        correoelectronico_contact=correoelectronico.get()
        numerotelefono_worker=numerotelefono.get()
        salario_worker=salario.get()
        if nombre_worker=='' or apellido_worker==''or correoelectronico_contact=='' or numerotelefono_worker=='' or salario_worker=='':
            tkMessageBox.showinfo("Warning","¡Complete el formato de informacion correctamente!")
        else:
            selecteditem = (tree.item(tree.focus()))['values']
            base_conexion.execute('UPDATE TRABAJADORES SET nombre=?,apellido=?,correoelectronico=?,numerotelefono=?,salario=? WHERE ID = ?', (nombre_worker,apellido_worker,correoelectronico_contact,numerotelefono_worker,salario_worker, selecteditem[0]))
            base_conexion.commit()
            tkMessageBox.showinfo("Message","¡Se ha actualizado la base de datos correctamente!")
            vision_base_datos()
            base_conexion.close()
 
    def eliminar_informacion():
        base_de_datos()
        if not tree.selection():
            tkMessageBox.showwarning("Warning","¡No has seleccionado ningún dato para borrar!")
        else:
            result = tkMessageBox.askquestion("Eliminar informacion", "¿Desea eliminar estos datos?", icon="warning")
            if result == 'yes' and "si":
                contents = (tree.item(tree.focus()))
                selecteditem = contents['values']
                tree.delete(tree.focus())
                conexion_db=base_conexion.execute("delete FROM TRABAJADORES WHERE ID = %d" % selecteditem[0])
                base_conexion.commit()
                conexion_db.close()
                base_conexion.close()
 
 
    def buscar_datos():
        base_de_datos()
        if SEARCH.get() != "":
            tree.delete(*tree.get_children())
            conexion_db=base_conexion.execute("SELECT * FROM TRABAJADORES WHERE Fnombre LIKE ?", ('%' + str(SEARCH.get()) + '%',))
            for data in conexion_db.fetchall():
                tree.insert('', 'end', values=(data))
            conexion_db.close()
            base_conexion.close()
 
    def vision_base_datos():
        base_de_datos()
        tree.delete(*tree.get_children())
        conexion_db=base_conexion.execute("SELECT * FROM TRABAJADORES")
        for data in conexion_db.fetchall():
            tree.insert('', 'end', values=(data))
            tree.bind("<Double-1>",seleccion_informacion)
        conexion_db.close()
        base_conexion.close()
        
    def seleccion_informacion(self):
        selecteditem = (tree.item(tree.focus()))['values']
        nombre.set(selecteditem[1])
        apellido.set(selecteditem[2])
        correoelectronico.set(selecteditem[3])
        numerotelefono.set(selecteditem[4])
        salario.set(selecteditem[5])
       
    vision_completa_programa()
    if __name__=='__main__':
        mainloop()
 
programa_cliente.mainloop()
