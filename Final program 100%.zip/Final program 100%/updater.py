from tkinter.font import BOLD
from huepy import *
import time
import requests
import urllib.request
from pyunpack import Archive
import os
clear = lambda: os.system('cls')

def main():
    def main_login():
        user = ["ivan","dani"]
        password = ["123","123@"]
        time.sleep(2)
        print("Loading login...")
        time.sleep(2)
        clear()
        print("Updater Login 1 Parking Managment IA")
        x_1 = input("Enter username: ")
        x_2 = input("Enter password: ")
        if x_1 in user and x_2 in password:
            time.sleep(3)
            print(bold(lightgreen('[!] Login Succesful')))
            text()
        else:
            time.sleep(3)
            print(bold(red("[X] Incorrect Credentials")))
            time.sleep(2)
            clear()
            print("Quitting program...")
            time.sleep(4)
        
    def text():
        print("Downloading your program...")
        time.sleep(3)
        download()
    def download():
        url = 'https://github.com/OGLightMoon/IA2/archive/refs/heads/main.zip'
        r = requests.get(url)
        urllib.request.urlretrieve(url, "IA-Program.zip")
        time.sleep(2)
        print(bold(lightgreen('[+] Program Downloaded Succesfuly')))
        time.sleep(2)
        choice_client = input("Want to unpack the winrar file: ")
        if choice_client == "Yes" or "yes" or "y":
            print("Unpacking winrar file...")
            time.sleep(2)
            unpack_rar()
        else:
            input("Press enter to exit")
    def unpack_rar():
        Archive("IA-Program.zip").extractall(".")
        print(bold(lightgreen('[+] Program Unpacked Succesfuly')))
        input('Press enter to exit program')
    main_login()
main()

